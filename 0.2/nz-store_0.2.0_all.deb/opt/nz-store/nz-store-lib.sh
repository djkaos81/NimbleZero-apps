# SPDX-License-Identifier: GPL-2.0-only
# nz-store-lib.sh - shared by nz-store (menu, normal user) and nz-store-backend (root).
#
# Three sources, each cached as one catalogue file in $C:
#   apps.tsv  NimbleZero apps          (NimbleZero-apps repository)
#   deps.tsv  dependencies             (NimbleZero-dependencies repository)
#   m5.tsv    M5Stack apps             (M5Stack's app index + the official list)
# Catalogue line, fields separated by the ASCII unit separator (octal 037; a tab would
# not do, the shell's read drops empty tab fields):
#   name, version, size, sha256, url, depends, provides, title, section, description,
#   needs-system
# section "hidden": a package that is not listed (NZ-Hidden: yes; the Store's own update).
# needs-system: the lowest system serial the package works on (NZ-Needs-System), or empty.
C=/data/cache/nz-store
OFFICIAL=/usr/share/nz/store-official.list
RUNTIME=nz-m5-runtime
# The package file of every installed M5Stack app is kept here (one per app, replaced on
# update, deleted when the app is removed): M5Stack's server keeps no old versions, so
# without it a working app could not be put back once its newer version needs something
# NimbleZero does not have.
KEPT=/data/packages/kept
US=$(printf '\037'); TAB=$(printf '\t')
# The Store itself: the system brings one (version in $STORE_BASE/store-version); a newer
# one can be installed from the apps repository as the unlisted package nz-store, into
# $STORE_PKG.  nz-store and nz-store-backend hand over to it while it is the newer one.
STORE_BASE=/usr/lib/nz; STORE_PKG=/opt/nz-store
store_ver() { v=$(sed -n 1p "$1/store-version" 2>/dev/null); echo "${v:-0}"; }

store_conf() {   # repository addresses; /etc/nz/store.conf may replace them
	PKGSET=$(sed -n 's/^PACKAGES=//p' /etc/nz-release)      # the package set this image was built with
	DEPS_URL=https://raw.githubusercontent.com/djkaos81/NimbleZero-dependencies/packages/$PKGSET/
	APPS_URL=https://raw.githubusercontent.com/djkaos81/NimbleZero-apps/packages/$PKGSET/
	M5_INDEX=https://cardputerzero.github.io/packages/dists/stable/main/binary-arm64/Packages
	[ -r /etc/nz/store.conf ] && . /etc/nz/store.conf
	return 0
}

# Packages file ($1) -> catalogue on stdout, newest version of each package only.
# $2 = address the Filename fields are relative to ("" if they are absolute already).
catalogue() {
	awk -v base="$2" 'BEGIN { RS=""; FS="\n"; OFS="\037" }
	{
		p=v=s=h=u=d=pr=ti=se=t=ns=""; hid=0
		# a field can go on in the next lines (they begin with a blank): join them first,
		# or a long Depends is read as its first line only
		# Not the description: its first line is the summary shown in the list, the lines
		# after it are the long text (paragraphs, " ." lines), which the Store has no place for.
		f = 0
		for (i = 1; i <= NF; i++) {
			if ($i !~ /^[ \t]/) { f = i; continue }
			if (f && $f !~ /^Description:/) { sub(/^[ \t]+/, "", $i); $f = $f " " $i }
			$i = ""
		}
		for (i = 1; i <= NF; i++) {
			if ($i ~ /^Package: /) p = substr($i, 10)
			else if ($i ~ /^Version: /) v = substr($i, 10)
			else if ($i ~ /^Size: /) s = substr($i, 7)
			else if ($i ~ /^SHA256: /) h = substr($i, 9)
			else if ($i ~ /^Filename: /) u = substr($i, 11)
			else if ($i ~ /^Depends: /) d = substr($i, 10)
			else if ($i ~ /^Provides: /) pr = substr($i, 11)
			else if ($i ~ /^NZ-Title: /) ti = substr($i, 11)
			else if ($i ~ /^Section: /) se = substr($i, 10)
			else if ($i ~ /^Description: /) t = substr($i, 14)
			else if ($i ~ /^NZ-Hidden: yes/) hid = 1
			else if ($i ~ /^NZ-Needs-System: /) ns = substr($i, 18) + 0
		}
		gsub(/\037/, " ", t); gsub(/\037/, " ", d); gsub(/\037/, " ", ti)
		if (ti == "") ti = p
		if (hid) se = "hidden"
		if (p != "" && v != "" && u != "" && h != "") print p, v, s, h, base u, d, pr, ti, se, t, ns
	}' "$1" | sort -t "$US" -k1,1 | {
		prev=; best=; bv=
		while IFS="$US" read -r p v rest; do
			if [ "$p" != "$prev" ]; then
				[ -n "$best" ] && printf '%s\n' "$best"
				prev=$p; best="$p$US$v$US$rest"; bv=$v
			elif dpkg --compare-versions "$v" gt "$bv" 2>/dev/null; then best="$p$US$v$US$rest"; bv=$v
			fi
		done
		[ -n "$best" ] && printf '%s\n' "$best"
	}
}

# Every package name this system has or provides, one per line -> file $1
have_names() {
	dpkg-query -W -f='${db:Status-Status} ${Package}\n${db:Status-Status} ${Provides}\n' 2>/dev/null |
		sed -n 's/^installed //p' | tr ',' '\n' | sed 's/^ *//; s/[ (].*//' | grep . | sort -u > "$1"
}

# Work out what installing something needs.
#   stdin : lines "name<US>depends"
#   $1    : file from have_names;  $2 : dependency catalogue (deps.tsv; may be missing)
#   stdout: "name<TAB>ok<TAB>pkg pkg ..."      packages to download first, in install order
#           "name<TAB>missing<TAB>dep dep ..." dependencies that nothing here can supply
# Version restrictions in Depends are not evaluated (as in the first Store); names only.
plan() {
	awk -F'\037' -v havef="$1" -v depsf="$2" '
	function name(s) { sub(/^ */, "", s); sub(/[ (:].*/, "", s); return s }
	function resolve(dstr, stack,    n, i, items, alts, m, j, a, ok, got) {
		n = split(dstr, items, ",")
		for (i = 1; i <= n; i++) {
			if (items[i] ~ /^ *$/) continue
			m = split(items[i], alts, "|"); ok = 0; got = ""
			for (j = 1; j <= m; j++) if (name(alts[j]) in have) ok = 1
			if (ok) continue
			for (j = 1; j <= m && got == ""; j++) { a = name(alts[j]); if (a in prov) got = prov[a] }
			if (got == "") { if (!(name(alts[1]) in miss)) { miss[name(alts[1])] = 1; misslist = misslist " " name(alts[1]) }; continue }
			if (got in visit) continue
			visit[got] = 1
			if (index(stack, " " got " ")) continue
			resolve(ddep[got], stack got " ")
			order = order " " got
		}
	}
	BEGIN {
		while ((getline l < havef) > 0) have[l] = 1
		while ((getline l < depsf) > 0) {
			split(l, f, "\037"); prov[f[1]] = f[1]; ddep[f[1]] = f[6]
			k = split(f[7], pv, ",")
			for (i = 1; i <= k; i++) { a = name(pv[i]); if (a != "" && !(a in prov)) prov[a] = f[1] }
		}
	}
	{
		delete visit; delete miss; order = ""; misslist = ""
		resolve($2, " ")
		if (misslist != "") print $1 "\tmissing\t" substr(misslist, 2)
		else print $1 "\tok\t" substr(order, 2)
	}'
}

cat_line() { awk -F'\037' -v n="$2" '$1==n' "$1" 2>/dev/null; }   # $1 catalogue file, $2 name
cat_field() { printf '%s' "$1" | cut -d"$US" -f"$2"; }             # $1 line, $2 field number
installed_ver() { dpkg-query -W -f='${db:Status-Status} ${Version}' "$1" 2>/dev/null | sed -n 's/^installed //p'; }

# Depends of an M5Stack app as the Store sees them: its own plus the M5Stack app runtime.
m5_depends() { [ -n "$1" ] && printf '%s, %s' "$RUNTIME" "$1" || printf '%s' "$RUNTIME"; }

# Installed packages that would stop working without package $1 (space separated).
# An M5Stack app needs the M5Stack app runtime without saying so in its Depends.
needed_by() {
	dpkg-query -W -f="\${Package}$US\${db:Status-Abbrev}$US\${Provides}$US\${Depends}\n" 2>/dev/null |
	awk -F'\037' -v t="$1" -v rt="$RUNTIME" '
	function name(s) { sub(/^ */, "", s); sub(/[ (:].*/, "", s); return s }
	substr($2, 2, 1) == "i" {
		n++; pk[n] = $1; held[n] = (substr($2, 1, 1) == "h"); dp[n] = $4
		k = split($1 "," $3, a, ",")
		for (i = 1; i <= k; i++) { x = name(a[i]); if (x == "") continue; if ($1 == t) mine[x] = 1; else other[x] = 1 }
	}
	END {
		for (q = 1; q <= n; q++) {
			if (pk[q] == t) continue
			hit = 0
			if (t == rt && !held[q] && pk[q] !~ /^nz-/) hit = 1
			k = split(dp[q], it, ",")
			for (i = 1; i <= k && !hit; i++) {
				m = split(it[i], al, "|"); viaT = 0; viaO = 0
				for (j = 1; j <= m; j++) { x = name(al[j]); if (x in other) viaO = 1; else if (x in mine) viaT = 1 }
				if (viaT && !viaO) hit = 1
			}
			if (hit) out = out " " pk[q]
		}
		print substr(out, 2)
	}'
}

# Installed packages of the NimbleZero repositories for which the lists have a newer
# version: "name<TAB>installed<TAB>listed<TAB>source<TAB>size", one per line.  This is
# what is left over from an older system version after a new image was flashed (a package
# set belongs to one system version), or a package that was updated in the repository.
outdated() {
	dpkg-query -W -f='${Package}\t${db:Status-Status}\t${Version}\n' 2>/dev/null |
	awk -F'\t' -v d="$C/deps.tsv" -v a="$C/apps.tsv" '
		BEGIN { while ((getline l < d) > 0) { split(l, f, "\037"); v[f[1]] = f[2]; s[f[1]] = "deps"; z[f[1]] = f[3] }
		        while ((getline l < a) > 0) { split(l, f, "\037"); if (f[9] == "hidden") continue; v[f[1]] = f[2]; s[f[1]] = "apps"; z[f[1]] = f[3] } }
		$2 == "installed" && ($1 in v) && v[$1] != $3 { print $1 "\t" $3 "\t" v[$1] "\t" s[$1] "\t" z[$1] }' |
	while IFS="$TAB" read -r n have listed src size; do
		# only a newer listed version is an update; an installed version that is newer
		# than the list (a build under test, installed by hand) is left alone
		newer "$listed" "$have" && printf '%s\t%s\t%s\t%s\t%s\n' "$n" "$have" "$listed" "$src" "$size"
	done
}
newer() { dpkg --compare-versions "$1" gt "$2" 2>/dev/null; }   # is version $1 newer than $2?
